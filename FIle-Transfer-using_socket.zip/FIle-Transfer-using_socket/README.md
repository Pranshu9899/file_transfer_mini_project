# File Transfer using TCP Socket in Python3
A simple client-server program, where client send a file to server. 


